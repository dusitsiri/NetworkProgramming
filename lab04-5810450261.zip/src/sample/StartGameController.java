package sample;


import com.sun.org.apache.xpath.internal.SourceTree;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

import java.io.IOException;


public class StartGameController {

    //Home Page
    @FXML
    private Button home;

    @FXML
    private void homePage(ActionEvent event) {
        p1 = new int[3][3];
        p2 = new int[3][3];
        Button reset = (Button) event.getSource();
        Stage stage = (Stage) reset.getScene().getWindow();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("TicTacToe.fxml"));
        try {
            stage.setScene(new Scene(loader.load(), 800, 600));
            stage.show();
        } catch (IOException event1) {
            event1.printStackTrace();
        }
    }

    //reset Game
    @FXML
    private Button reset;

    @FXML
    private void resetGame(ActionEvent event) {
        p1 = new int[3][3];
        p2 = new int[3][3];
        Button reset = (Button) event.getSource();
        Stage stage = (Stage) reset.getScene().getWindow();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("StartGame.fxml"));
        try {
            stage.setScene(new Scene(loader.load(), 800, 600));
            stage.show();
        } catch (IOException event1) {
            event1.printStackTrace();
        }
    }

    //turn and player
    @FXML
    private Label turnplayer;
    @FXML
    private String player1 = "";

    //X
    @FXML
    private Label x1;
    @FXML
    private Label x2;
    @FXML
    private Label x3;
    @FXML
    private Label x4;
    @FXML
    private Label x5;
    @FXML
    private Label x6;
    @FXML
    private Label x7;
    @FXML
    private Label x8;
    @FXML
    private Label x9;

    //O
    @FXML
    private Circle c1;
    @FXML
    private Circle c2;
    @FXML
    private Circle c3;
    @FXML
    private Circle c4;
    @FXML
    private Circle c5;
    @FXML
    private Circle c6;
    @FXML
    private Circle c7;
    @FXML
    private Circle c8;
    @FXML
    private Circle c9;

    //mouseclick each rectangle
    public void mouseClicked1(MouseEvent event) {
        if (player1.equals("")) {
            player1 = "play1";
            c1.setVisible(true);
            turnplayer.setText("Player2 Turn");
        } else if (player1.equals("play1") && !(c1.isVisible())) {
            x1.setVisible(true);
            player1 = "";
            turnplayer.setText("Player1 Turn");
        }
        int x = 0;
        int y = 0;
        data(x, y, player1);
    }

    public void mouseClicked2(MouseEvent event) {
        if (player1.equals("")) {
            player1 = "play1";
            c2.setVisible(true);
            turnplayer.setText("Player2 Turn");
        } else if (player1.equals("play1") && !(c2.isVisible())) {
            x2.setVisible(true);
            player1 = "";
            turnplayer.setText("Player1 Turn");
        }
        int x = 0;
        int y = 1;
        data(x, y, player1);
    }

    public void mouseClicked3(MouseEvent event) {
        if (player1.equals("")) {
            player1 = "play1";
            c3.setVisible(true);
            turnplayer.setText("Player2 Turn");
        } else if (player1.equals("play1") && !(c3.isVisible())) {
            x3.setVisible(true);
            player1 = "";
            turnplayer.setText("Player1 Turn");
        }
        int x = 0;
        int y = 2;
        data(x, y, player1);
    }

    public void mouseClicked4(MouseEvent event) {
        if (player1.equals("")) {
            player1 = "play1";
            c4.setVisible(true);
            turnplayer.setText("Player2 Turn");
        } else if (player1.equals("play1") && !(c4.isVisible())) {
            x4.setVisible(true);
            player1 = "";
            turnplayer.setText("Player1 Turn");
        }
        int x = 1;
        int y = 0;
        data(x, y, player1);
    }

    public void mouseClicked5(MouseEvent event) {
        if (player1.equals("")) {
            player1 = "play1";
            c5.setVisible(true);
            turnplayer.setText("Player2 Turn");
        } else if (player1.equals("play1") && !(c5.isVisible())) {
            x5.setVisible(true);
            player1 = "";
            turnplayer.setText("Player1 Turn");
        }
        int x = 1;
        int y = 1;
        data(x, y, player1);
    }

    public void mouseClicked6(MouseEvent event) {
        if (player1.equals("")) {
            player1 = "play1";
            c6.setVisible(true);
            turnplayer.setText("Player2 Turn");
        } else if (player1.equals("play1") && !(c6.isVisible())) {
            x6.setVisible(true);
            player1 = "";
            turnplayer.setText("Player1 Turn");
        }
        int x = 1;
        int y = 2;
        data(x, y, player1);
    }

    public void mouseClicked7(MouseEvent event) {
        if (player1.equals("")) {
            player1 = "play1";
            c7.setVisible(true);
            turnplayer.setText("Player2 Turn");
        } else if (player1.equals("play1") && !(c7.isVisible())) {
            x7.setVisible(true);
            player1 = "";
            turnplayer.setText("Player1 Turn");
        }
        int x = 2;
        int y = 0;
        data(x, y, player1);
    }

    public void mouseClicked8(MouseEvent event) {
        if (player1.equals("")) {
            player1 = "play1";
            c8.setVisible(true);
            turnplayer.setText("Player2 Turn");
        } else if (player1.equals("play1") && !(c8.isVisible())) {
            x8.setVisible(true);
            player1 = "";
            turnplayer.setText("Player1 Turn");
        }
        int x = 2;
        int y = 1;
        data(x, y, player1);
    }

    public void mouseClicked9(MouseEvent event) {
        if (player1.equals("")) {
            player1 = "play1";
            c9.setVisible(true);
            turnplayer.setText("Player2 Turn");
        } else if (player1.equals("play1") && !(c9.isVisible())) {
            x9.setVisible(true);
            player1 = "";
            turnplayer.setText("Player1 Turn");
        }
        int x = 2;
        int y = 2;
        data(x, y, player1);
    }

    //database of each player
    int[][] tables = {{1, 2, 3},
            {4, 5, 6},
            {7, 8, 9}};
    int[][] p1 = new int[3][3];
    int[][] p2 = new int[3][3];
    int moveCount1;
    int moveCount2;
    String draw = "";
    @FXML
    private Label winner;

    public void data(int x, int y, String player) {
        for (int i = 0; i < p1.length; i++) {
            for (int j = 0; j < p1.length; j++) {
                if (p1[x][y] == 0 && player.equals("play1")) {
                    p1[x][y] = tables[x][y];
                    moveCount1++;
                    if (!check1(x, y, p1) && draw.equals("Draw")) {
                        winner.setText("Draw");
                        break;
                    }
                    else if (check1(x, y, p1) && draw.equals("")) {
                        winner.setText("Player1 Win");
                    }
                    break;
                }
                else if (p2[x][y] == 0 && player.equals("")) {
                    p2[x][y] = tables[x][y];
                    moveCount2++;
                    if (!check2(x, y, p2) && draw.equals("Draw")) {
                        winner.setText("Draw");
                        break;
                    }
                    else if (check2(x, y, p2) && draw.equals("")) {
                        winner.setText("Player2 Win");
                    }
                    break;
                }
            }
//            for (int v = 0; v < p1.length; v++) {
//                for (int f = 0; f < p1.length; f++) {
//                    System.out.print(p1[v][f] + " ");
//                }
//                System.out.println("moveCount1: " + moveCount1);
//            }
//            System.out.println();
//            for (int k = 0; k < p1.length; k++) {
//                for (int u = 0; u < p1.length; u++) {
//                    System.out.print(p2[k][u] + " ");
//                }
//                System.out.println();
//            }
//            System.out.println("moveCount2: " + moveCount2);
//            break;

        }
    }

    boolean checkWin = false;
    public boolean check1(int x, int y, int[][] p) {
        //check row
        for (int i = 0; i < tables.length; i++) {
            if (p[x][i] != tables[x][i]) {
                break;
            } else if (i == tables.length - 1) {
                checkWin = true;
                break;
            }
        }

        //check column
        for (int i = 0; i < tables.length; i++) {
            if (p[i][y] != tables[i][y]) {
                break;
            } else if (i == tables.length - 1) {
                checkWin = true;
                break;
            }
        }

        //check diagonal
        if (x == y) {
            for (int i = 0; i < tables.length; i++) {
                if (p[i][i] != tables[i][i]) {
                    break;
                } else if (i == tables.length - 1) {
                    checkWin = true;
                    break;
                }
            }
        }

        //check anti diagonal
        if (x + y == tables.length - 1) {
            for (int i = 0; i < tables.length; i++) {
                if (p[i][(tables.length - 1) - i] != tables[i][(tables.length - 1) - i]) {
                    break;
                } else if (i == tables.length - 1) {
                    checkWin = true;
                    break;
                }
            }
        }

        //check draw
        if (moveCount1 >= 5) {
            draw = "Draw";
        }
        return checkWin;
    }

    boolean checkWin2 = false;
    public boolean check2(int x, int y, int[][] p2) {
        //check row
        for (int i = 0; i < tables.length; i++) {
            if (p2[x][i] != tables[x][i]) {
                break;
            } else if (i == tables.length - 1) {
                checkWin2 = true;
                break;
            }
        }

        //check column
        for (int i = 0; i < tables.length; i++) {
            if (p2[i][y] != tables[i][y]) {
                break;
            } else if (i == tables.length - 1) {
                checkWin2 = true;
                break;
            }
        }

        //check diagonal
        if (x == y) {
            for (int i = 0; i < tables.length; i++) {
                if (p2[i][i] != tables[i][i]) {
                    break;
                } else if (i == tables.length - 1) {
                    checkWin2 = true;
                    break;
                }
            }
        }

        //check anti diagonal
        if (x + y == tables.length - 1) {
            for (int i = 0; i < tables.length; i++) {
                if (p2[i][(tables.length - 1) - i] != tables[i][(tables.length - 1) - i]) {
                    break;
                } else if (i == tables.length - 1) {
                    checkWin2 = true;
                    break;
                }
            }
        }

        //check draw
        if (moveCount2 >= 5) {
            draw = "Draw";
        }
        return checkWin2;
    }
}

