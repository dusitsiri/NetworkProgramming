package sample;

public class SettingsController {
}
